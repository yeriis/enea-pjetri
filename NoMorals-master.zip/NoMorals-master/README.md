# NoMorals Alt Gen
### What does this do?
This tool will use a predefined list of bot names on roblox, find which groups that bot is in, then scrape every other bot in the group.
Using BurnedGood's method (password = reversed usernames), accounts found will be logged in User:Pass format in alts.txt.
Any roblox multitool can be used to turn User:Pass into cookies, which you can then use to bot.
### How do I set this up?
1. Download [Node.js](https://nodejs.org/en/)
2. `git clone` this repository, or download it as zip.
3. Open a terminal in the project folder
4. Run `npm install` to install the required node modules
5. Run `node main.js` to run the tool
6. Enjoy! Alts will be output in alts.txt
